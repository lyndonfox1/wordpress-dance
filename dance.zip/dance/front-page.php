<?php get_header(); ?>
<h1>Front page</h1>
<?php get_template_part('template-parts/content');
get_footer(); ?>