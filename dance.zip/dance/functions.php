<?php
/**
 * Dance theme functions and definitions
 */

require_once get_template_directory() . '/inc/setup.php';
require_once get_template_directory() . '/inc/custom-post-types.php';
require_once get_template_directory() . '/inc/taxonomies.php';
require_once get_template_directory() . '/inc/custom-meta-boxes.php';
require_once get_template_directory() . '/inc/widgets.php'; 
require_once get_template_directory() . '/inc/customization/customization.php'; 